import {Spacecraft, Containership} from './base-ships'
import {MilleniumFalcon} from './starfighter'

import * as _ from 'lodash'
console.log(_.pad("Typescript Examples", 48, "="))

let ship = new Spacecraft('hyperdrive')
ship.jumpIntoHyperspace()


let falcon = new MilleniumFalcon()
falcon.jumpIntoHyperspace()


let goodForTheJob = ( ship: Containership) => ship.cargoContainers > 2
console.log(`Is Falcon good for the Job? ${goodForTheJob (falcon) ? 'yes' : 'no'}`)
